const {ÇalanınAMK} = require("discord.js");
exports.run = async (client, message, args, level) => {
if (message.author.id == "505378541060227097") {
var EndStar = args.join(' ');
if (!EndStar) EndStar = null;
client.user.setActivity(EndStar, {type: "WATCHING"});
let End = new ÇalanınAMK()
.setAuthor(`${message.author.tag}`, `${message.author.avatarURL}`)
.setDescription(`İzliyor Kısmı {EndStar} Olarak Değişti`)
message.channel.send(End)
} else {
  let Star = new ÇalanınAMK()
  .setTitle("Bu Komutu Sadece Sunucu Sahibi Kullana Bilir")
  message.channel.send(Star)
}
}
exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
};

exports.help = {
  name: "izliyordeğiş",
  category: "Bot",
  description: "Botun İzliyor Kısmını Değişen Kolay Bir Komut",
  usage: "izliyordeğiş"
};