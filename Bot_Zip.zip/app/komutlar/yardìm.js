const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
    let EndStar = new Discord.RichEmbed()
    .setDescription("**:exclamation:  Yardım Komutları   :exclamation: **")
    .setColor("#15f153")
    .addField("1vs1", "İstediğiniz Bir Kişiyle Vs Atarsınız Ama Tek Bir Kazanan Var.")
    .addField("Oylama", "Oylama Yapar.")
.addField("Afk", "Eğer Bir İşin Çıktıysa Bu Komutu Kullan.")
.addField("Ascii", "İstediğiniz şeyi bota yazdırır.")
.addField("Atarürk-çerçeve", "Profil Resminiz İçin Çerçeve.")
.addField("Atom", "Atom Bombası Atarsınız.")
.addField("Avatarım", "Avatarınızı Atar.")
.addField("Aze", " Etiketledğiniz Kişinin Profiline Azerbaycan Effecti Eklenir.")
.addField("AşkÖlçer", "Aşk Ölçmeni Sağlar.")
.addField("Ban", "Kullanıcı Yasaklamanızı Sağlar.")
.addField("Bayrak", "Türk Bayrağı Gösterir")
.addField("Bilgilerim", "Bu Komutu Kullanan Kişi Hakkında Bilgi Verir.")
.addField("Csgo", "Csgo İstatistiklerini Gösterir.")
.addField("DcNitro", "Profil Fotorafınıza Discord Nitro Effecti Ekler.")
.addField("Doğrula", "Kullanıcı İçin Doğrulandı Rolü Verir.")
.addField("Duyuru", "Yetkili İçindir Duyuru Yapmasını Sağlar")
.addField("Düello", "İstediğiniz Bir kişiyle Düello Yaparsınız.")
.addField("Efkar-vs", "İstediğiniz 2 Kişiyi Savaştırırsınız.")
.addField("Geçici-Sustur", "Kullanıcıyı Süreli Olarak Susturur.")
.addField("Gif-Ara", "Mesajınızla İlgili Gifleri Giphy'da Arar.")
.addField("Hesapla", "Belirtilen İşlemi Yapar.")
.addField("İcon", "Sunucunun İconunu Gösterir.")
.addField("İsim-Ayarla", "Profil Bilginizdeki İsmi Ayarlar.")
.addField("İstatistik", "Botun İstatistiklerini Gösterir.")

    
    message.channel.send(EndStar).then(m => m.delete(30000));

    let EndStar2 = new Discord.RichEmbed()
    .setColor("#15f153")
.addField("KodYaz", "Kod Yazmaya Yarar.")
.addField("Korkut ", "Böööööööö") 
.addField("Küfür-Engelle", "Küfür Engelleme Sistemini Açıp Kapatmanızı Sağlar.")
.addField("Link-Kısalt", "İztediğiniz Url yi Kısaltır.")
.addField("Load", "Yeni Eklenen Komutu Yükler.")
.addField("MesajKüçült", "Mesajınızı Küçültür.")
.addField("Otorol-Ayarla", "Sunucuya Girenlere Verilecek Rolü Ayarlar.")
.addField("OtorolMesajKapat", "Otorol Verildikten Sonra ki Mesajları Kapatır.")
.addField("QrKod", "QrKod Oluşturur.")
.addField("RastgeleŞifre", "Random Şifre Atar.")
.addField("ReBoot", "Botu Yeniden Başlatır.")
.addField("Reklam", "Reklam Yapar.")
.addField("RolBilgi", "Rol Hakkında Bilgi Verir.")
.addField("Sa-As", "Sa-as Ayarlamanızı Sağlar.")
.addField("Sahibim", "Botun Sahibini Gösterir.")
.addField("Sayaç", "Sayacı Ayarlar.")
.addField("Yavaş-Mod", "Sohbete Yazma Sınırı (Süre) Ekler")
.addField("SteamStore", "Steam Mağzasını Gösterir.")
.addField("Sunucu", "Bulunduğun Sunucu Hakkında Bilgi Verir.")
.addField("SunucuResmi", "Sunucu Resmininin Linkini Atar. ")
.addField("Temizle", "Belirtilen Miktar Mesaj Siler.")
.addField("UnAfk", "Artık Afk Değilsen Bu Komutu Yaz.")
.addField("UnBan", "İstediğiniz Kişinin Banını Kaldırır.") 
.addField("Yardım", "Bütün Yardım Komutlarını Gösterir. ")
.addField("Youtube", "Youtube'da Arama Yaparsınız")  
    message.channel.send(EndStar2).then(m => m.delete(30000));

let EndStar3 = new Discord.RichEmbed()
.setColor("ff0000")
.addField(":exclamation: Hızlı Ol Bu Mesaj Kısa Bir Süre Sonra Silincek :exclamation: ", ":warning: :warning: :warning: ")
.setFooter('OnexWare', )
message.channel.send(EndStar3).then(m => m.delete(30000) );
  message.channel.bulkDelete(1)
  
}


exports.conf = {
    enabled: true,
    guildOnly: false,
    aliases: ['komut', 'komutlar', 'command', 'yardım', 'help', 'halp', 'y', 'h', 'commands'],
    permLevel: 0
};

exports.help = {
  name: 'yardım',
  description: 'Bütün Yardım komutlarını verir.',
  usage: 'yardım'
};