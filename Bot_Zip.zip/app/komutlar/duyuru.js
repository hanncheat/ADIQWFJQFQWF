const Discord = require('discord.js');

exports.run = (client, message, args, member) => {
  
      if (!message.member.hasPermission("MANAGE_MESSAGES")) return message.reply(`Bu komutu kullanabilmek için **Mesajları Yönet** iznine sahip olmalısın!`).then(m => m.delete(10000));

    let mesaj = args.slice(0).join(' ');
    if (mesaj.length < 1) return message.channel.send(':x: Duyuruya yazmak için bir şeyler yazınız.');
  let incidentchannel = message.guild.channels.find(`name`, "「💻」duyuru📣");
    if(!incidentchannel) return message.channel.send(":x: **Duyuru** kanalını bulamıyorum.");

    incidentchannel.send(`<@526737552670195712> | **Duyuru**\n\n- ${mesaj}`);
  message.channel.send(':white_check_mark: Duyuru başarıyla yapıldı.')
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['duyuryap', 'duyur'],
  permLevel: 1,
      kategori: "Yetkili"

};

exports.help = {
  name: 'duyuru',
  description: 'Duyuru',
  usage: 'duyuru <mesaj>'
};