const Discord = require("discord.js");
var Jimp = require('jimp');

exports.run = async (client, message, args) => {
      const DBL = require('dblapi.js')
  const dbl = new DBL('eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjQ3OTM1NTc5NDI3ODcxMTI5NiIsImJvdCI6dHJ1ZSwiaWF0IjoxNTQ2ODg3NjkyfQ.2I2f1s0vFRe3odcQA0-o1MfMYDAIWahM_yuGX7jcBZE', client) 
  
  dbl.hasVoted(message.author.id).then(voted => {
    if(voted) {
    var user = message.mentions.users.first() || message.author;
    if (!message.guild) user = message.author;
   
    message.channel.send(`:timer: | Fotoğraf işleniyor, lütfen bekleyin.`).then(m => m.delete(1000));

Jimp.read(user.avatarURL, (err, image) => {
    image.resize(315, 310)
    Jimp.read("https://api.eggsybot.xyz/api/cerceve?cerceve=ataturk&url=https://api.eggsybot.xyz/pub/resources/frames/ataturk.png", (err, avatar) => {
        avatar.resize(315, 320)
        image.composite(avatar, 1, 0).write(`./img/snip/${client.user.id}-${user.id}.png`);
        setTimeout(function() {
            message.channel.send(new Discord.Attachment(`./img/snip/${client.user.id}-${user.id}.png`));
        }, 1000);
      
    });

});
          } else {
      message.channel.send("Bu komutu kullanabilmek için 12 saatte bir https://discordbots.org/bot/479355794278711296/vote sitesinden bota oy vermeniz gerekmektedir. Onaylanması birkaç dakika sürebilir, lütfen bekleyin.")
    }
  })
};


exports.conf = {
    enabled: true,
    guildOnly: false,
    aliases: [],
    permLevel: 0
  };
  
  exports.help = {
    name: 'atatürk-çerçeve',
    description: 'tbc',
    usage: 'tbc'
  };