const Discord = require("discord.js");

module.exports.run = async (client, message, args) => {
          const DBL = require('dblapi.js')
  const dbl = new DBL('eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjQ3OTM1NTc5NDI3ODcxMTI5NiIsImJvdCI6dHJ1ZSwiaWF0IjoxNTQ2MDA3NDUyfQ.IoDE_DWBIZdKnwoG4wpQNlVdXE89GvsNaJ9NBhCegWc', client) 
  
  dbl.hasVoted(message.author.id).then(voted => {
    if(voted) {



    let youtube = args.slice(0).join('+');

        let link = `https://www.youtube.com/results?search_query=` + youtube;
        if(!youtube)return message.reply(`Lütfen bir kelime giriniz`)
        if(!link)return message.reply("Console error")
        let embed = new Discord.RichEmbed()
 
         
     .setColor("RED")
         
          .setTimestamp()
        
          .addField('Aktivasyon:', 'Youtubede Aranıyor')

          .addField("Aranan:", `${args.slice(0).join(' ')}`)

          .addField('Link:', `${link}`)
         
          .setFooter("Avatarın", message.author.avatarURL);
          
              message.channel.send(embed);
              message.author.send(`Aradığın link bulundu ${link} Sunucu: ${ message.guild.name}`);

                       } else {
      message.channel.send("Bu komutu kullanabilmek için 12 saatte bir https://discordbots.org/bot/479355794278711296/vote sitesinden bota oy vermeniz gerekmektedir. Onaylanması birkaç dakika sürebilir, lütfen bekleyin.")
    }
  })
};
    




exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0,
  kategori: "Kullanıcı"

};

exports.help = {
  name: 'youtube',
  description: 'Tüm komutları listeler. İsterseniz bir komut hakkında yardım eder..',
  usage: 'youtube'
};