const Discord = require('discord.js');

exports.run = function(client, message, args) {
 let user = message.mentions.users.first();
   
    
    if (message.mentions.users.size < 1) return message.reply('Herhangi birini, belirtmelisin!').catch(console.error);
 
    const oldur=new Discord.RichEmbed()
    .setColor("0x808080")
    .setDescription(message.author.username + ` ${user}` + ' adlı kişiyi, Sikti! ')
    .setImage('http://gif.cdnmex.com/wp-content/uploads/2018/2018-01-30/eleman-cekici-kadina-fena-sokuyor_1.gif')
    .setFooter("Seni Küçük Orosbu!", client.user.avatarURL)
    return message.channel.send(oldur);

};

exports.conf = {
  enabled: true,
  guildOnly: true,
  aliases: [],
  permLevel: 4
};

exports.help = {
  name: 'sik',
  description: 'Belirtilen kişiyi, öldürür!',
  usage: 'sik'
};